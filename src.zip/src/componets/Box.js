
import './Box.css'
import BoxChild from './BoxChild'
import SecondBox from './secondBox' 
let box = [
    {
        Title:"Extra happiness days",
        Image:'/images/a1.jpg',
        About:'See All Offers'
    },
    {
        Title:"Up to 60% off | Double door refrigerators",
        Image:'/images/a2.jpg',
        About:'See All Offers'
    },
    {
        Title:"Coupon Carnival | Special offers for you",
        Image:'/images/b3.jpg',
        About:'See All Offers'
    },
    {
        Title:"Earn up to ₹7,500 on cashback",
        Image:'/images/img17.jpg',
        About:'See All Offers'
    },
]

function Box()
    {   
        return ( <>

<div className="main">
       
                { box.map(function(value)
                { 
                    return (
                        
                        <div className="text12">
                    <BoxChild  Title ={value.Title}
                                        Image ={value.Image}
                                        About ={value.About}
                    
                    
                    />
                    </div>)
               })}
            
           </div>


                <SecondBox />

            </> 
        
    )}

    export default Box ;
