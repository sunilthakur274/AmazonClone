import './secondBox.css'
import SecBoxchild from './secBoxchild';
//import Register from './Register'
import Login from './loginPage'

let a = [
    {   
        Heading:"Unlock savings on home, kitchen & more",
        img1:'/images/img1.jpg',
        About1:'Decor',

        img2:'/images/img2.jpg',
        About2:'Cooking',

        img3:'/images/img3.jpg',
        About3:'Sports',

        img4:'/images/img4.jpg',  
        About4:'Home',  
        Link:'See all offers'
    },
    {
        Heading:"Up to 70% off | Upgrade to latest appliances",
        img1:'/images/img5.jpg',
        About1:'Front Loads',

        img2:'/images/img6.jpg',
        About2:'Refrigertator',

        img3:'/images/img7.jpg',
        About3:'Inverter Acs',

        img4:'/images/img8.jpg',  
        About4:'Microwaves',  
        Link:'See all offers'
    },
    {
        Heading:"Up to 70% off | Upgrade to latest appliances",
        img1:'/images/img9.jpg',
        About1:'Refrigertator',

        img2:'/images/img10.jpg',
        About2:'kitchen acc',

        img3:'/images/img11.jpg',
        About3:'Essentials',

        img4:'/images/img12.jpg',  
        About4:'clothing',  
        Link:'See all offers'
    },
    {
        Heading:"Deals on beauty | ​Up to 70% off",
        img1:'/images/img13.jpg',
        About1:'Skincare',

        img2:'/images/img14.jpg',
        About2:'Haircare',

        img3:'/images/img15.jpg',
        About3:'Makeup',

        img4:'/images/img16.jpg',  
        About4:'Bath shower',  
        Link:'See all offers'
    }
   
]
function SecondBox()
{
    return (<>
            <div className="imgg1">
                {a.map(function(value)
                {
                        
                    return <div className="imgg2">
                                                    <SecBoxchild Heading ={value.Heading}
                                                                img1= {value.img1}
                                                                About1 ={value.About1}

                                        img2= {value.img2}
                                        About2 ={value.About2}

                                        img3= {value.img3}
                                        About3 ={value.About3}

                                        img4= {value.img4} 
                                        About4 ={value.About4}
                                        Link = {value.Link}
                           />
                           </div>
                })}
            </div>
                    <Login />

                
                    

    </>)
}
export default SecondBox;