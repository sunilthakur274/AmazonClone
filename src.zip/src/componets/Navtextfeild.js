import './Navtextfeild.css'
import { FaSearch } from 'react-icons/fa';
function SearchFeild()
{
    return  (<div className="p1">

                <select id="a1"><option>All</option>
                                <option>All Department</option>
                                <option>Arts And Crafts</option> </select>
                   
                <input type ="text" alt ="" id="input12"/>

                <button type="submit" id="a12" > <FaSearch /></button>
            
            </div>)
}
export default SearchFeild ;