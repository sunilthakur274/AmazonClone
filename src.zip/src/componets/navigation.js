import Carousal from './bodypart'
import './navigation.css'
import {nav} from '../Shared/Common'
function Navgation()
{
 
    

    return ( <div>
        <div className="item5">
        {
            nav.map(function(value)
            {
                return(<a href="#"><li>{value}</li></a>)
            })
        }
    </div>

            <Carousal />
            
            </div>)
           

}
export default Navgation ;