import { FaCartPlus } from 'react-icons/fa';
import './carticon.css'
function Icon()
{
 return(
 <div className='text'>
       <FaCartPlus />
 </div>)
}
export default Icon ;