import './Register.css'
import React,{useState} from 'react'

let register =[
    {   
       name:"firstName",
       type:"text",
       place:"first name",
       size:"28",
    },
    {   name:"lastName",
        type:"text",
        place:"Last name",
        size:"28",
     },
     { 
        name:"Email",
        type:"Email",
        place:"Enter Email",
        size:"27",
     },
     {   
        name:"Image",       
        type:"file",
        place:"Select Image",
        size:"28",
     },
    {  
        name:"Password",
        type:"Password",
        place:"Password",
        size:"28",
        padding:"24px"
    },

]

function Register(props)
{
        
            const[userdata,setUserData] = useState({firstName:'',lastName:'',Email:'',Image:'', Password:''});
            
            const RegisterData = (event) => 
            {
                return setUserData((prevdata) =>
                {
                     return { ...prevdata,
                             [event.target.name] : event.target.value }
                })
            };
            //console.log(userdata)

            

            const submitHandle = (event) =>
            {
                    event.preventDefault();
                   
                    console.log(userdata)
                    props.onSaveExpenseData(userdata);
                  
            }

        

    return(<>
    <form onSubmit={submitHandle}>
            <div className="register">
                <h2 style={{margin:"20px"}}>Create Account</h2>
                
               {register.map(function(value)
               {
                    return (
                              <div > 
                                        
                                        <h5    style={{display:'inline',padding:'20px'}}>{value.place} </h5>
                                        
                                        <input  size={value.size}
                                                name={value.name} 
                                                type ={value.type}  id="input13" onChange={RegisterData}/>
                                    


                            </div>) 
                            
                           

               })} 
                         <button type ="submit" id="btn12">Submit</button>
                </div>
                </form>
                
              
    </>)
}
export default Register ;