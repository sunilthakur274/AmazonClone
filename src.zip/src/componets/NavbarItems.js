import './NavbarItems.css' 
import Navgation from './navigation'
import SearchFeild from './Navtextfeild'
import Icon from './carticon'

function NavItems(props)
{
    return (
    <div>
            <div className = "item1">
            
             <div className="itema1">
                <img src ="/images/amazone3.jpg" alt =" " id="img1"/>
              </div>


            <div className="item2">
              <p>{props.item[0]}</p>
            </div>

            
            <SearchFeild />  

            <div className="item3">  
                <p> {props.item[1]} </p>
            </div>

            <div className="item4">
              <p> {props.item[2]} </p>
            </div>        

            <div>
            <Icon />
          </div>

    </div>
              
          <div>
            <Navgation />
          </div>

         

    </div>

    )

            

}
export default NavItems