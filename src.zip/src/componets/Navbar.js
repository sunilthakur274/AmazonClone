import NavItems from './NavbarItems';
import './navbar.css'
//import Common from '../Shared/Common';
function Navbar(props)
{
    let navbar = ["Hello Select your Address","Hello,Sign in Account & lists","Return & orders"]

    

    return (<div>
        <p><NavItems item={navbar}/></p>
    </div>)
}
export default Navbar ;