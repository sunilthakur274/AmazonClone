
import { useState } from "react"

function Reg()
{   
    const[formdata,setFormData] = useState({fistName:" ", lastName:" ",email:" "})
    

    const getData = (event) => {
                                 setFormData(prevFormdata =>
                                 {
                                    return {
                                                ...prevFormdata,
                                                [event.target.name] : event.target.value
                                    }
                                 }
    )}

                    const submitHandle = (event) =>
                    {
                            event.preventDefault();
                            const data =
                            {
                                firstName :'firstName',
                                lastName :'lastName',
                                email :'email',
                            }
                            console.log(data)
                    }


    return (<>  < form onSubmit={submitHandle}>
    
                    <input type="text" name ="firstname" placeholder="firstname" onChange={getData}/>

                    <input type="text" name ="LastName" placeholder="lastName" onChange={getData}/>

                    <input type="text" name ="email" placeholder="email" onChange={getData}/>

                    <button type="submit">submit</button>
                    </form>
                    
            </>)
}
export default Reg;