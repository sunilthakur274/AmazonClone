
import './App.css';
import Navbar from './componets/Navbar';
import Cart from './shoppingCart/cart';
//import Bind from './Bind';
//import Uncontrolled from './Ref';
//import Hooks from './Hooks';
function App()
{
  return (<><Navbar /> 

          <Cart />
  
  {/* <Bind /> */}
  
  {/* <Uncontrolled /> 
  <Hooks /> */}
  </>)
}
export default App;