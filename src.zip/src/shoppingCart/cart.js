import './cart.css'
let cartData = 
[
    {
        img:'/images/c1.jpg',
        item:'Parasnath Folding Plastic Stool (Color Randomly Selected',       
        
        Deal:'DEAL OF THE DAY',
        
        Price:'Rs 663',
        MRP:'MRP 1499.00 (50% off)',
        Delivery:'Get it by Monday, November 7',
        freeDelvivery:'FREE Delivery over ₹499.',
        Amazone:'Fulfilled by Amazon',
        EndingDate:'Ends in 17 days '
    },
    {
        img:'/images/c4.jpg',
        item:'Parasnath Portable Plastic Folding Metal Leg Step Stool (Color Randomly Selected',       
        
        Deal:'DEAL OF THE DAY',
        
        Price:'Rs 863',
        MRP:'MRP 2599.00 (50% off)',
        Delivery:'Get it by Sunday, November 7',
        freeDelvivery:'FREE Delivery over ₹499.',
        Amazone:'Fulfilled by Amazon',
        EndingDate:'Ends in 7 days '
    }
]



function Cart()
{
    return(<>   

        <div className="main-container">
                {cartData.map(function(value)
                {
                   return(<>
                   
                <div className='cart-containter'>
                    <img src={value.img}/><br/><br/>
                    
                    <span className='content'>{value.item}</span><br/>
                    <span className='cart-item1'>{value.Deal}</span><br/>
                    <span className='cart-item2'>{value.Price}</span><br/>
                    <span  className='cart-item3'>{value.MRP}</span><br/><br/>
                    <span className='cart-item4'>{value.Delivery}</span><br/><br/>
                    <span className='cart-item5'>{value.freeDelvivery}</span><br/>
                    <span className='cart-item6'>{value.Amazone}</span><br/>
                    <span className='cart-item7'>{value.EndingDate}</span>
                </div>
                    
                    </>)
                })}
        </div>
    
    </>)
}
export default Cart