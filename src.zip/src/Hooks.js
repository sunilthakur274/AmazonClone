import React,{useEffect} from 'react'

// WillUnAmount Component

/*
function Hooks()
{
   useEffect(()=>
   {
    return () =>{
        console.log("Dead");
        console.log("Almost dead");
    }
   })
}
export default Hooks;
*/

// DiD UnAmount Componet
function Hooks()
{
    useEffect(()=>{
              
        console.log("hello how are you")  
    },[])
    return  (<p>hello sunil</p>)
}
export default Hooks ;

// Update Unamount Component

