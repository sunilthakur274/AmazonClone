export const nav = ["All","Sell","Best Sellers","Today's Deal","Mobiles","CustomerService","Electronics","Books","Fashion"
,"Home & Kitchen" ,"Prime","Coupnes","Computers"]

